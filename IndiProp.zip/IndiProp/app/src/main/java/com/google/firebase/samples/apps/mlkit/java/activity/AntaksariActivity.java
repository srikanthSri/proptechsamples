package com.google.firebase.samples.apps.mlkit.java.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.alphabetik.Alphabetik;
import com.google.firebase.samples.apps.mlkit.R;
import com.google.firebase.samples.apps.mlkit.java.adapter.ItemAdapter;
import com.google.firebase.samples.apps.mlkit.java.bean.DataModel;

import java.util.ArrayList;
import java.util.List;

public class AntaksariActivity extends AppCompatActivity {

    //Implement your data as you prefer, but sort it.
    private ListView listView;
    ArrayList<DataModel> list;

    //Example of data
    final String[] orderedData = new String[]{"A Psychopath(Song of 2016)", "A Boy Named Sue", "Bama Lama Bama Loo", "Blood Makes Noise", "Bomber", "Call Me Sister Carol", "Don't You Want Me", "Egyptian Shumba", "Election Day",
            "Faster", "God Says No", "Hard On for Love", "I Feel for You", "Jake the Peg", "Keep an Eye on Love", "Last Words", "Maybe I Can Paint Over That", "Natty Supper", "Never Give Up on a Dream",
            "Ode to Boy", "Perfume", "Queen of Denmark", "Religious Songs", "Sally", "Sara", "Take the Bitter With the Sweet", "Unchained Melody", "Walkin' Like Brando", "You're Gonna Miss Me", "Zombie"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_antaksari);
        list = new ArrayList<>();
        for(String name : orderedData){
            DataModel dataModel = new DataModel(name);
            list.add(dataModel);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        //Listview implementation, with SORTED list of DATA
        listView = (ListView) findViewById(R.id.listView);
        ItemAdapter adapter = new ItemAdapter(0, list, this);
        listView.setAdapter(adapter);

        //Implementation
        Alphabetik alphabetik = (Alphabetik) findViewById(R.id.alphSectionIndex);
        alphabetik.onSectionIndexClickListener(new Alphabetik.SectionIndexClickListener() {
            @Override
            public void onItemClick(View view, int position, String character) {
                String info = " Position = " + position + " Char = " + character;
                Log.i("View: ", view + "," + info);
                //Toast.makeText(getBaseContext(), info, Toast.LENGTH_SHORT).show();
                listView.smoothScrollToPosition(getPositionFromData(character));
            }
        });
        //Set
        //alphabetik.setLetterToBold(letter);
    }

    private int getPositionFromData(String character) {
        int position = 0;
        for (String s : orderedData) {
            String letter = "" + s.charAt(0);
            if (letter.equals("" + character)) {
                return position;
            }
            position++;
        }
        return 0;
    }
}
