package com.google.firebase.samples.apps.mlkit.java.fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.samples.apps.mlkit.R;
import com.google.firebase.samples.apps.mlkit.java.adapter.BookAdapter;
import com.google.firebase.samples.apps.mlkit.java.adapter.SlideImageAdapter;
import com.google.firebase.samples.apps.mlkit.java.bean.Book;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

public class PropHomeFragment extends Fragment{
    private RecyclerView mRecyclerViewTop10;
    private RecyclerView mRecyclerViewPet, mRecyclerViewBolly, mRecyclerViewMBabies, mRecyclerViewHolly, mRecyclerViewRegionalHits, mRecyclerViewRent;
    private RecyclerView mRecyclerViewMoodSong;
    private View view;
    private ViewPager viewPager;
    private static int NUM_PAGES = 0;
    private static int currentPage = 0;
    private BookAdapter mAdapter;
    private ArrayList<Integer> imagesArray = new ArrayList<Integer>();
    private static final Integer[] IMAGES = new Integer[4];
    private TextView heading, url,video, address, owner;

    private Button btnSubscribe;


    SharedPreferences preferences;
    String cityName;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initiateViewPagerItems();
    }

    private void initiateViewPagerItems() {
        IMAGES[0] = R.drawable.uddipa;
        IMAGES[1] = R.drawable.uddipa1;
        IMAGES[2] = R.drawable.uddipa2;
        IMAGES[3] = R.drawable.uddipa3;
    }

    public PropHomeFragment(String cityName){
        this.cityName = cityName;
    }

    public static PropHomeFragment newInstance(String cityName) {
        PropHomeFragment f = new PropHomeFragment(cityName);
        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        preferences = getActivity().getSharedPreferences("MyPref", 0);

        view = inflater.inflate(R.layout.fragment_prop, container, false);
        viewPager = (ViewPager) view.findViewById(R.id.viewPager);
        heading = (TextView) view.findViewById(R.id.heading);
        url = (TextView) view.findViewById(R.id.url);
        video = (TextView) view.findViewById(R.id.video);
        address = (TextView) view.findViewById(R.id.address);
        owner = (TextView) view.findViewById(R.id.owner);
        btnSubscribe = view.findViewById(R.id.btnSubscribe);

        url.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.uddipa.com/"));
            startActivity(browserIntent);
        });

        video.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=OeXn3onUVHQ&feature=youtu.be"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setPackage("com.google.android.youtube");
            startActivity(intent);
        });

        heading.setOnClickListener(v -> {
            Intent intent2 = new Intent(); intent2.setAction(Intent.ACTION_SEND);
            intent2.setType("text/plain");
            intent2.putExtra(Intent.EXTRA_TEXT, "Uddipa Website : https://www.uddipa.com/" );
            startActivity(Intent.createChooser(intent2, "Share via"));
        });

        address.setOnClickListener(v -> {
            String map = "http://maps.google.co.in/maps?q=" + "1, Kashi Nath Dutta Rd, Nainan Para, Satchasi Para, Kolkata, West Bengal 700036";
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(map));
            startActivity(i);
        });

        owner.setOnClickListener(v -> {
            Toast.makeText(getActivity(), "Downloading brochure", Toast.LENGTH_SHORT).show();
        });

        btnSubscribe.setOnClickListener(v -> {
            String dial = "tel:033 4040 8080";
            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
        });

        LinearLayoutManager mLayoutManager
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);

        initViewPager();


        return view;
    }

    private void initViewPager() {
        for (int i = 0; i < IMAGES.length; i++) {
            imagesArray.add(IMAGES[i]);
        }
        viewPager.setAdapter(new SlideImageAdapter(getActivity(), imagesArray));
        NUM_PAGES = IMAGES.length;
        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES) {
                    currentPage = 0;
                }
                viewPager.setCurrentItem(currentPage++, true);
            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 3000, 3000);

    }
}
