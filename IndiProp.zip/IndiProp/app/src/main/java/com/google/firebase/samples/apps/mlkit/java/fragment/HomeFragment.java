package com.google.firebase.samples.apps.mlkit.java.fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.samples.apps.mlkit.R;
import com.google.firebase.samples.apps.mlkit.java.activity.StepCountActivity;
import com.google.firebase.samples.apps.mlkit.java.adapter.BookAdapter;
import com.google.firebase.samples.apps.mlkit.java.adapter.SlideImageAdapter;
import com.google.firebase.samples.apps.mlkit.java.bean.Book;
import com.google.firebase.samples.apps.mlkit.java.stepcount.StepListener;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

public class HomeFragment extends Fragment{
    private RecyclerView mRecyclerViewTop10;
    private RecyclerView mRecyclerViewPet, mRecyclerViewBolly, mRecyclerViewMBabies, mRecyclerViewHolly, mRecyclerViewRegionalHits, mRecyclerViewRent;
    private RecyclerView mRecyclerViewMoodSong;
    private View view;
    private ViewPager viewPager;
    private static int NUM_PAGES = 0;
    private static int currentPage = 0;
    private BookAdapter mAdapter;
    private ArrayList<Integer> imagesArray = new ArrayList<Integer>();
    private static final Integer[] IMAGES = new Integer[4];
    private TextView motivational, workout, fitness, tvLanguageHeader, seekbarPropTxt;
    private SeekBar seekbarProp;

    SharedPreferences preferences;
    String cityName;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initiateViewPagerItems();
    }

    private void initiateViewPagerItems() {
        IMAGES[0] = R.drawable.ad1;
        IMAGES[1] = R.drawable.ad2;
        IMAGES[2] = R.drawable.ad3;
        IMAGES[3] = R.drawable.ad4;
    }

    public HomeFragment(String cityName){
        this.cityName = cityName;
    }

    public static HomeFragment newInstance(String cityName) {
        HomeFragment f = new HomeFragment(cityName);
        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        preferences = getActivity().getSharedPreferences("MyPref", 0);

        view = inflater.inflate(R.layout.fragment_home, container, false);
        viewPager = (ViewPager) view.findViewById(R.id.viewPager);
        LinearLayoutManager mLayoutManager
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        motivational = (TextView) view.findViewById(R.id.motivational);
        workout = (TextView) view.findViewById(R.id.workout);
        fitness = (TextView) view.findViewById(R.id.fitness);
        tvLanguageHeader = (TextView) view.findViewById(R.id.tvLanguageHeader);

        seekbarProp = (SeekBar) view.findViewById(R.id.seekbarProp);
        seekbarPropTxt = (TextView) view.findViewById(R.id.seekbarPropTxt);

        seekbarProp.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressChangedValue = seekbarProp.getMin();

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChangedValue = progress;
                seekbarPropTxt.setText(progressChangedValue + "KM");
                reloadPropList(progressChangedValue);
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });


        mRecyclerViewTop10 = (RecyclerView) view.findViewById(R.id.rvTopBookList);
        mRecyclerViewTop10.setHasFixedSize(true);
        mRecyclerViewTop10.setLayoutManager(mLayoutManager);
        //setSongsTimeBased();
        preparePropList();

        mRecyclerViewMoodSong = (RecyclerView) view.findViewById(R.id.mRecyclerViewMoodSong);
        LinearLayoutManager mLayoutManagerMood
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);

        mRecyclerViewMoodSong.setLayoutManager(mLayoutManagerMood);
        initRecommendedSet();

        mRecyclerViewPet = (RecyclerView) view.findViewById(R.id.rvRecentBookList);
        LinearLayoutManager mLayoutManagerPet
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        mRecyclerViewPet.setHasFixedSize(true);
        mRecyclerViewPet.setLayoutManager(mLayoutManagerPet);
        preparePetSongList();

        mRecyclerViewMBabies = (RecyclerView) view.findViewById(R.id.mRecyclerViewMBabies);
        LinearLayoutManager mLayoutManagerBaby
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);

        mRecyclerViewMBabies.setHasFixedSize(true);
        mRecyclerViewMBabies.setLayoutManager(mLayoutManagerBaby);
        prepareBabySongList();

        mRecyclerViewBolly = (RecyclerView) view.findViewById(R.id.mRecyclerViewBolly);
        LinearLayoutManager mLayoutManagerBolly
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        mRecyclerViewBolly.setHasFixedSize(true);
        mRecyclerViewBolly.setLayoutManager(mLayoutManagerBolly);
        prepareBollySongList();

        mRecyclerViewRegionalHits = (RecyclerView) view.findViewById(R.id.mRecyclerViewRegionalHits);
        LinearLayoutManager mLayoutManagerTolly
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        mRecyclerViewRegionalHits.setHasFixedSize(true);
        mRecyclerViewRegionalHits.setLayoutManager(mLayoutManagerTolly);
        prepareTollySongList();

        mRecyclerViewRent = (RecyclerView) view.findViewById(R.id.mRecyclerViewRent);
        LinearLayoutManager mLayoutManagerRent
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        mRecyclerViewRent.setHasFixedSize(true);
        mRecyclerViewRent.setLayoutManager(mLayoutManagerRent);
        prepareRentList();

        mRecyclerViewHolly = (RecyclerView) view.findViewById(R.id.mRecyclerViewHolly);
        LinearLayoutManager mLayoutManagerHolly
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        mRecyclerViewHolly.setHasFixedSize(true);
        mRecyclerViewHolly.setLayoutManager(mLayoutManagerHolly);
        prepareHollySongList();
        determineCurrentDayTime();
        initViewPager();

        motivational.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // startActivity(new Intent(getActivity(), StepCountActivity.class));
            }
        });

//        if(cityName.equalsIgnoreCase("Hyderabad")){
//            tvLanguageHeader.setText("Telegu Hits");
//        }

        return view;
    }

    private void setSongsTimeBased() {
        String dateTime = determineCurrentDayTime();
        if (dateTime.contains("AM")) {
            prepareMorningSongList();
        }
        if ((dateTime.contains("Mon") || dateTime.contains("Tue") || dateTime.contains("Wed") || dateTime.contains("Thu")) && dateTime.contains("PM")) {
            prepareEveningSongList();
        }
        if ((dateTime.contains("Fri") || dateTime.contains("Sat") || dateTime.contains("Sun")) && dateTime.contains("PM")) {
            prepareWeekendSongList();
        }
        mRecyclerViewTop10.setAdapter(mAdapter);
    }

    private String determineCurrentDayTime() {
        DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy, h:mm a");
        String date = df.format(Calendar.getInstance().getTime());
        return date;
    }

    private void prepareMorningSongList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.devotional);
        happyMoodSng1.setTitle("Devotional Song");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.romanticsong);
        happyMoodSng2.setTitle("Romantic Song");
        happySongs.add(happyMoodSng2);
        Book happyMoodSng3 = new Book();
        happyMoodSng3.setResources(R.drawable.party);
        happyMoodSng3.setTitle("Soothing songs");
        happySongs.add(happyMoodSng3);
        Book happyMoodSng4 = new Book();
        happyMoodSng4.setResources(R.drawable.instrumental);
        happyMoodSng4.setTitle("Instrumental");
        happySongs.add(happyMoodSng4);
        mAdapter = new BookAdapter(happySongs, getActivity());
    }

    private void prepareEveningSongList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.party);
        happyMoodSng1.setTitle("Latest releases");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.romanticsong);
        happyMoodSng2.setTitle("Romantic Song");
        happySongs.add(happyMoodSng2);
        Book happyMoodSng3 = new Book();
        happyMoodSng3.setResources(R.drawable.instrumental);
        happyMoodSng3.setTitle("Relaxing Music");
        happySongs.add(happyMoodSng3);
        mAdapter = new BookAdapter(happySongs, getActivity());
    }

    private void prepareWeekendSongList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.party);
        happyMoodSng1.setTitle("Party Song");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.party);
        happyMoodSng2.setTitle("Night Hiphop Song");
        happySongs.add(happyMoodSng2);
        Book happyMoodSng3 = new Book();
        happyMoodSng3.setResources(R.drawable.party);
        happyMoodSng3.setTitle("Top Block Blaster Song");
        happySongs.add(happyMoodSng3);
        mAdapter = new BookAdapter(happySongs, getActivity());
    }

    private void prepareHappySongList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.party);
        happyMoodSng1.setTitle("Party Song");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.romanticsong);
        happyMoodSng2.setTitle("Romantic Song");
        happySongs.add(happyMoodSng2);
        Book happyMoodSng3 = new Book();
        happyMoodSng3.setResources(R.drawable.party);
        happyMoodSng3.setTitle("Top Block Blaster Song");
        happySongs.add(happyMoodSng3);
        mAdapter = new BookAdapter(happySongs, getActivity());
    }

    private void prepareSadSongList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.sadsong);
        happyMoodSng1.setTitle("Motivation speech");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.sadsong);
        happyMoodSng2.setTitle("Breakup Song");
        happySongs.add(happyMoodSng2);
        Book happyMoodSng3 = new Book();
        happyMoodSng3.setResources(R.drawable.sadsong);
        happyMoodSng3.setTitle("Light Song");
        happySongs.add(happyMoodSng3);
        Book happyMoodSng4 = new Book();
        happyMoodSng4.setResources(R.drawable.romanticsong);
        happyMoodSng4.setTitle("Romantic Song");
        happySongs.add(happyMoodSng4);
        mAdapter = new BookAdapter(happySongs, getActivity());
    }

    private void preparePetSongList() {
        List<Book> petSongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.shop);
        happyMoodSng1.setTitle("Diamond Plaza - 2nd floor");
        petSongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.shop);
        happyMoodSng2.setTitle("Shyambazar 5 crossing point");
        petSongs.add(happyMoodSng2);
        mAdapter = new BookAdapter(petSongs, getActivity());
        mRecyclerViewPet.setAdapter(mAdapter);
    }

    List<Book> happySongs = new ArrayList<>();

    private void preparePropList() {
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.property);
        happyMoodSng1.setTitle("Ambuja Uddipa");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.property);
        happyMoodSng2.setTitle("Prestige Shantiniketan");
        happySongs.add(happyMoodSng2);
        mAdapter = new BookAdapter(happySongs, getActivity(), 1);
        mRecyclerViewTop10.setAdapter(mAdapter);
    }

    private void reloadPropList(int progress) {
        if(progress > 20 && progress <= 30) {
            Book happyMoodSng2 = new Book();
            happyMoodSng2.setResources(R.drawable.property);
            happyMoodSng2.setTitle("Avishi Property");
            happySongs.add(happyMoodSng2);
            Book happyMoodSng3 = new Book();
            happyMoodSng3.setResources(R.drawable.property);
            happyMoodSng3.setTitle("Siddha Lake View");
            happySongs.add(happyMoodSng3);
        }
        mAdapter = new BookAdapter(happySongs, getActivity());
        mRecyclerViewTop10.setAdapter(mAdapter);
    }

    private void prepareBabySongList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.garage);
        happyMoodSng1.setTitle("Single Owner Garage for rent");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.garage);
        happyMoodSng2.setTitle("Garage fr sale");
        happySongs.add(happyMoodSng2);
        Book happyMoodSng3 = new Book();
        happyMoodSng3.setResources(R.drawable.garage);
        happyMoodSng3.setTitle("Garage in 5Lakhs");
        happySongs.add(happyMoodSng3);
        Book happyMoodSng4 = new Book();
        happyMoodSng4.setResources(R.drawable.garage);
        happyMoodSng4.setTitle("Two wheeler garage");
        happySongs.add(happyMoodSng4);
        mAdapter = new BookAdapter(happySongs, getActivity(), 2);
        mRecyclerViewMBabies.setAdapter(mAdapter);
    }

    private void prepareHollySongList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.englishsong);
        happyMoodSng1.setTitle("Top 20 2020");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.englishsong);
        happyMoodSng2.setTitle("Latest Hollywood Songs");
        happySongs.add(happyMoodSng2);
        Book happyMoodSng3 = new Book();
        happyMoodSng3.setResources(R.drawable.englishsong);
        happyMoodSng3.setTitle("Song from 90's");
        happySongs.add(happyMoodSng3);
        Book happyMoodSng4 = new Book();
        happyMoodSng4.setResources(R.drawable.englishsong);
        happyMoodSng4.setTitle("evergreen Albums");
        happySongs.add(happyMoodSng4);
        mAdapter = new BookAdapter(happySongs, getActivity());
        mRecyclerViewHolly.setAdapter(mAdapter);
    }

    private void prepareBollySongList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.bollywood);
        happyMoodSng1.setTitle("Top 20 2020");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.bollywood);
        happyMoodSng2.setTitle("Latest Hollywood Songs");
        happySongs.add(happyMoodSng2);
        Book happyMoodSng3 = new Book();
        happyMoodSng3.setResources(R.drawable.bollywood);
        happyMoodSng3.setTitle("Song from 90's");
        happySongs.add(happyMoodSng3);
        Book happyMoodSng4 = new Book();
        happyMoodSng4.setResources(R.drawable.bollyevergreen);
        happyMoodSng4.setTitle("evergreen Albums");
        happySongs.add(happyMoodSng4);
        mAdapter = new BookAdapter(happySongs, getActivity());
        mRecyclerViewBolly.setAdapter(mAdapter);
    }

    private void prepareTollySongList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.cowork);
        happyMoodSng1.setTitle("Ambuja Ecospace - New town");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.cowork);
        happyMoodSng2.setTitle("Cowork space at Laketown");
        happySongs.add(happyMoodSng2);
        mAdapter = new BookAdapter(happySongs, getActivity());
        mRecyclerViewRegionalHits.setAdapter(mAdapter);
    }

    private void prepareRentList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.rent);
        happyMoodSng1.setTitle("PaintHouse on Rent");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.rent);
        happyMoodSng2.setTitle("Single Owner flat on rent - 2nd floor");
        happySongs.add(happyMoodSng2);
        Book happyMoodSng3 = new Book();
        happyMoodSng3.setResources(R.drawable.rent);
        happyMoodSng3.setTitle("Gated Community - 2BHK Rent");
        happySongs.add(happyMoodSng3);
        Book happyMoodSng4 = new Book();
        happyMoodSng4.setResources(R.drawable.rent);
        happyMoodSng4.setTitle("Rent for Bachelor - 1BHK");
        happySongs.add(happyMoodSng4);
        mAdapter = new BookAdapter(happySongs, getActivity());
        mRecyclerViewRent.setAdapter(mAdapter);
    }

    private void prepareNeutralSongList() {
        List<Book> happySongs = new ArrayList<>();
        Book happyMoodSng1 = new Book();
        happyMoodSng1.setResources(R.drawable.kolkata);
        happyMoodSng1.setTitle("Kolkata");
        happySongs.add(happyMoodSng1);
        Book happyMoodSng2 = new Book();
        happyMoodSng2.setResources(R.drawable.mumbai);
        happyMoodSng2.setTitle("Mumbai");
        happySongs.add(happyMoodSng2);
        Book happyMoodSng3 = new Book();
        happyMoodSng3.setResources(R.drawable.delhi);
        happyMoodSng3.setTitle("Delhi");
        happySongs.add(happyMoodSng3);
        Book happyMoodSng4 = new Book();
        happyMoodSng4.setResources(R.drawable.hyderbad);
        happyMoodSng4.setTitle("Hyderabad");
        happySongs.add(happyMoodSng4);
        Book happyMoodSng5 = new Book();
        happyMoodSng5.setResources(R.drawable.bangalore);
        happyMoodSng5.setTitle("Bangalore");
        happySongs.add(happyMoodSng5);
        Book happyMoodSng6 = new Book();
        happyMoodSng6.setResources(R.drawable.chennai);
        happyMoodSng6.setTitle("Chennai");
        happySongs.add(happyMoodSng6);
        mAdapter = new BookAdapter(happySongs, getActivity());
    }

    private void initRecommendedSet() {

        prepareNeutralSongList();
        mRecyclerViewMoodSong.setAdapter(mAdapter);
    }

    private void initViewPager() {
        for (int i = 0; i < IMAGES.length; i++) {
            imagesArray.add(IMAGES[i]);
        }
        viewPager.setAdapter(new SlideImageAdapter(getActivity(), imagesArray));
        NUM_PAGES = IMAGES.length;
        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES) {
                    currentPage = 0;
                }
                viewPager.setCurrentItem(currentPage++, true);
            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 3000, 3000);

    }

    /**
     * This function download the large files from the server
     *
     * @param filename
     * @param urlString
     * @throws MalformedURLException
     * @throws IOException
     */
    public static void downloadFileFromServer(String filename, String urlString) throws MalformedURLException, IOException {
        BufferedInputStream in = null;
        FileOutputStream fout = null;
        try {
            URL url = new URL(urlString);

            in = new BufferedInputStream(url.openStream());
            fout = new FileOutputStream(filename);

            byte data[] = new byte[1024];
            int count;
            while ((count = in.read(data, 0, 1024)) != -1) {
                fout.write(data, 0, count);
                System.out.println(count);
            }
        } finally {
            if (in != null)
                in.close();
            if (fout != null)
                fout.close();
        }
        System.out.println("Done");
    }

    @Override
    public void onResume() {
        super.onResume();
        if (preferences.getInt("steps", 0) > 10) {
            motivational.setVisibility(View.GONE);
            workout.setVisibility(View.VISIBLE);
            fitness.setVisibility(View.VISIBLE);
        } else {
            workout.setVisibility(View.GONE);
            fitness.setVisibility(View.GONE);
        }
    }

    class RetrieveFeedTask extends AsyncTask<String, Void, String> {

        private Exception exception;

        protected String doInBackground(String... urls) {
            try {
                downloadFileFromServer("sample.zim", urls[0]);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return "done";
        }

        protected void onPostExecute(String feed) {
            // TODO: check this.exception
            // TODO: do something with the feed
            System.out.println("Download completed");
        }
    }
}
