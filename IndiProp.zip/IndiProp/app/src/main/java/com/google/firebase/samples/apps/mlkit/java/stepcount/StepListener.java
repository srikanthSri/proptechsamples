package com.google.firebase.samples.apps.mlkit.java.stepcount;

public interface StepListener {

    public void step(long timeNs);

}
