package com.google.firebase.samples.apps.mlkit.java.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.samples.apps.mlkit.R;
import com.google.firebase.samples.apps.mlkit.java.view.ZoomableImageView;

import androidx.appcompat.widget.AppCompatSpinner;
import androidx.fragment.app.Fragment;
import com.google.firebase.samples.apps.mlkit.java.activity.MapsActivity;

import java.util.Random;

//import com.google.android.gms.vision.text.Line;

public class AmenitiesFragment extends Fragment implements AdapterView.OnItemSelectedListener {
    Button btnSubscribe, btnSubscription;
    View view;

    private ZoomableImageView imgFlat;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_amenities, container, false);
        btnSubscribe = view.findViewById(R.id.btnSubscribe);
        btnSubscription = view.findViewById(R.id.btnSubscription);
        imgFlat = view.findViewById(R.id.imgFlat);
        AppCompatSpinner spin = view.findViewById(R.id.spinnerAmenities);
        spin.setOnItemSelectedListener(this);

        Bitmap amenities = BitmapFactory.decodeResource(getActivity().getResources(),
                R.drawable.amenities);
        imgFlat.setImageBitmap(amenities);

        btnSubscription.setOnClickListener(v -> startActivity(new Intent(getActivity(), MapsActivity.class)));
        setZoomAnimation(0,1f,0,1f);
        return view;
    }

    private void setZoomAnimation(float fromX, float toX, float fromY, float toY){
        ScaleAnimation scal=new ScaleAnimation(fromX, toX, fromY, toY, Animation.RELATIVE_TO_SELF, (float)0.5,Animation.RELATIVE_TO_SELF, (float)0.5);
        scal.setDuration(500);
        scal.setFillAfter(true);
        imgFlat.setAnimation(scal);
    }

    private void zoomImage(){
        Random r = new Random();
        float minScale = 10f;
        float maxScale = 10f;
        float randomScale = minScale + (r.nextFloat() * (maxScale - minScale));

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        int centerX=-10;
        int centerY =-30;

        /*pass a value of focalX and focalY to scale image to center*/
//mPhotoView.setScale(randomScale, centerX, centerY, true);

        /*pass a value of focalX and focalY to scale image to top left corner*/
        imgFlat.setScaleX(centerX);
        imgFlat.setScaleY(centerY);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(position == 2)
            zoomImage();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
