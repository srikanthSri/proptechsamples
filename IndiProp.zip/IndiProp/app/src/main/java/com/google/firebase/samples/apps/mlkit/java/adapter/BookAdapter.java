package com.google.firebase.samples.apps.mlkit.java.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;


import com.google.firebase.samples.apps.mlkit.R;
import com.google.firebase.samples.apps.mlkit.java.activity.DetailsActivity;
import com.google.firebase.samples.apps.mlkit.java.activity.PropActivity;
import com.google.firebase.samples.apps.mlkit.java.activity.SongListActivity;
import com.google.firebase.samples.apps.mlkit.java.bean.Book;
import com.unity3d.player.UnityPlayerActivity;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by Rajhrita on 23 Sep 2017 023.
 */

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.CustomViewHolder> {
    private List<Book> books;
    private int mRowIndex = -1;
    private Context context;
    private int indicatorToHandleClick = 0;

    public BookAdapter(List<Book> books, Context context) {
        this.books = books;
        this.context = context;
    }

    public BookAdapter(List<Book> books, Context context, int indicatorToHandleClick) {
        this.books = books;
        this.context = context;
        this.indicatorToHandleClick = indicatorToHandleClick;
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.book_item_adpater, parent, false);

        return new CustomViewHolder(itemView);
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        holder.image.setBackgroundResource(books.get(position).getResources());
        holder.tvLanguage.setText(books.get(position).getTitle());
    }

    @Override
    public int getItemCount() {
        return books.size();
    }


    public void setData(List<Book> data) {
        if (books != data) {
            books = data;
            notifyDataSetChanged();
        }
    }

    public void setRowIndex(int index) {
        mRowIndex = index;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        public TextView tvLanguage;
        public RatingBar rbBook;
        public ImageView image;

        public CustomViewHolder(View view) {
            super(view);
            tvLanguage = (TextView) view.findViewById(R.id.tvBookTitle);
            rbBook = (RatingBar) view.findViewById(R.id.rbBook);
            image = (ImageView) view.findViewById(R.id.image);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(indicatorToHandleClick > 0){
                        switch (indicatorToHandleClick){
                            case 1:
                                context.startActivity(new Intent(context, PropActivity.class));
                                break;
                            case 2 :
                                context.startActivity(new Intent(context, UnityPlayerActivity.class));
                                break;
                        }
                    }
                    //context.startActivity(new Intent(context, SongListActivity.class));
                }
            });
        }
    }
}
