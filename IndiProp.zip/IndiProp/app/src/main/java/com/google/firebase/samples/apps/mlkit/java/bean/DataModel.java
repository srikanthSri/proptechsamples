package com.google.firebase.samples.apps.mlkit.java.bean;

public class DataModel {
    String name;
    public DataModel(String name) {
        this.name=name;
    }
    public String getName() {
        return name;
    }
}
