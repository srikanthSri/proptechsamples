package com.google.firebase.samples.apps.mlkit.java.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.google.firebase.samples.apps.mlkit.R;
import com.google.firebase.samples.apps.mlkit.java.adapter.ItemAdapter;
import com.google.firebase.samples.apps.mlkit.java.bean.DataModel;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class FavouriteFragment extends Fragment {

    private ListView listView;
    ArrayList<DataModel> list;
    private View view;

    //Example of data
    final String[] orderedData = new String[]{"A Psychopath(Song of 2016)", "Take the Bitter With the Sweet", "Unchained Melody", "Walkin' Like Brando", "You're Gonna Miss Me", "Zombie"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_song_list, container, false);
        list = new ArrayList<>();
        for(String name : orderedData){
            DataModel dataModel = new DataModel(name);
            list.add(dataModel);
        }

        listView = (ListView) view.findViewById(R.id.listView);
        ItemAdapter adapter = new ItemAdapter(2, list, getActivity());
        listView.setAdapter(adapter);

        return view;
    }
}
