package com.google.firebase.samples.apps.mlkit.java.adapter;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.samples.apps.mlkit.R;
import com.google.firebase.samples.apps.mlkit.java.bean.Book;
import com.google.firebase.samples.apps.mlkit.java.bean.DataModel;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by Rajhrita on 23 Sep 2017 023.
 */

public class ItemAdapter extends ArrayAdapter<DataModel> implements View.OnClickListener{
    private ArrayList<DataModel> dataSet;
    Context mContext;
    int index;
    MediaPlayer mediaPlayer;

    // View lookup cache
    private static class ViewHolder {
        TextView txtName;
        ImageView lyrics, delete, favourite, video, share, replay, play;
    }

    public ItemAdapter(int index, ArrayList<DataModel> data, Context context) {
        super(context, R.layout.item_adpater, data);
        this.dataSet = data;
        this.mContext=context;
        this.index=index;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.lyrics:
                if(mContext.getSharedPreferences("MyPref", 0).getBoolean("isSubscribed", false)) {
                    showLyrics();
                } else{
                    Toast.makeText(mContext, "Please take subscription to see lyrics", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.play:
                mediaPlayer = MediaPlayer.create(mContext, R.raw.sample);
                mediaPlayer.start();
                break;
            case R.id.replay:
                mediaPlayer = MediaPlayer.create(mContext, R.raw.sample);
                mediaPlayer.reset();
                mediaPlayer.start();
                break;
            case R.id.favourite:
                v.setBackground(mContext.getDrawable(R.drawable.ic_favorite_selected));
                Toast.makeText(mContext, "Added to favourite and downloading song", Toast.LENGTH_LONG).show();
                break;
            case R.id.share:
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, "Download Song Box App");
                i.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=com.bsbportal.music&hl=en");
                mContext.startActivity(Intent.createChooser(i, "To listen the music"));
                break;
            case R.id.video:
                Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + "CkOTPyzWTQE"));
                Intent webIntent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.youtube.com/watch?v=" + "CkOTPyzWTQE"));
                try {
                    mContext.startActivity(appIntent);
                } catch (ActivityNotFoundException ex) {
                    mContext.startActivity(webIntent);
                }
                break;
        }
    }

    private int lastPosition = -1;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        DataModel dataModel = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        ViewHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if (convertView == null) {

            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.item_adpater, parent, false);
            viewHolder.txtName = (TextView) convertView.findViewById(R.id.songTitle);
            viewHolder.lyrics = (ImageView) convertView.findViewById(R.id.lyrics);
            viewHolder.play = (ImageView) convertView.findViewById(R.id.play);
            viewHolder.share = (ImageView) convertView.findViewById(R.id.share);
            viewHolder.delete = (ImageView) convertView.findViewById(R.id.delete);
            viewHolder.video = (ImageView) convertView.findViewById(R.id.video);
            viewHolder.favourite = (ImageView) convertView.findViewById(R.id.favourite);
            viewHolder.replay = (ImageView) convertView.findViewById(R.id.replay);
            result=convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result=convertView;
        }
        lastPosition = position;

        if(index == 1){
            viewHolder.delete.setVisibility(View.VISIBLE);
            viewHolder.video.setVisibility(View.VISIBLE);
            viewHolder.favourite.setVisibility(View.VISIBLE);
        }

        if(index == 2){
            viewHolder.delete.setVisibility(View.VISIBLE);
            viewHolder.share.setVisibility(View.GONE);
            viewHolder.replay.setVisibility(View.VISIBLE);
        }

        if(!isAccessibilityServiceTurnedOn()){
            viewHolder.video.setVisibility(View.GONE);
            viewHolder.lyrics.setVisibility(View.GONE);
        }

        if(mContext.getSharedPreferences("MyPref", 0).getBoolean("isSubscribed", false)){
            viewHolder.lyrics.setBackgroundResource(R.drawable.ic_note);
        } else{
            viewHolder.lyrics.setBackgroundResource(R.drawable.ic_lock);
        }
        viewHolder.txtName.setText(dataModel.getName());
        viewHolder.lyrics.setOnClickListener(this);
        viewHolder.favourite.setOnClickListener(this);
        viewHolder.play.setOnClickListener(this);
        viewHolder.replay.setOnClickListener(this);
        viewHolder.video.setOnClickListener(this);
        viewHolder.share.setOnClickListener(this);
        // Return the completed view to render on screen
        return convertView;
    }

    private void showLyrics(){
        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
        alert.setTitle("Song Title : A Psychopath");
        final TextView input = new TextView (mContext);
        input.setPadding(20,10,10,0);
        input.setText(mContext.getResources().getString(R.string.lyrics));
        alert.setView(input);

        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Do something with value!
            }
        });
        alert.show();
    }

    private boolean isAccessibilityServiceTurnedOn(){
        String enabledServicesSetting = Settings.Secure.getString(mContext.getContentResolver(),  Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabledServicesSetting == null)
            return false;
        return true;
    }
}