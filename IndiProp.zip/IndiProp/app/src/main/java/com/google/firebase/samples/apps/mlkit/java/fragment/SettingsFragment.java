package com.google.firebase.samples.apps.mlkit.java.fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

//import com.google.android.gms.vision.text.Line;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.samples.apps.mlkit.R;
import com.google.firebase.samples.apps.mlkit.java.activity.DetailsActivity;
import com.google.firebase.samples.apps.mlkit.java.activity.SongListActivity;
import com.google.firebase.samples.apps.mlkit.java.adapter.ItemAdapter;
import com.google.firebase.samples.apps.mlkit.java.bean.DataModel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.fragment.app.Fragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SettingsFragment extends Fragment {
    Button btnSubscribe, btnSubscription;
    LinearLayout paymentLayout;
    View view;
    TextView tvSubs;
    SharedPreferences preferences;
    TextInputEditText searchField;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_subscription, container, false);
        paymentLayout = (LinearLayout) view.findViewById(R.id.paymentLayout);
        btnSubscribe = (Button) view.findViewById(R.id.btnSubscribe);
        btnSubscription = (Button) view.findViewById(R.id.btnSubscription);
        tvSubs = (TextView) view.findViewById(R.id.tvSubs);
        searchField = (TextInputEditText) view.findViewById(R.id.searchField);
        preferences = getActivity().getSharedPreferences("MyPref", 0);
//        if(preferences.getBoolean("isSubscribed", false)){
//            tvSubs.setVisibility(View.VISIBLE);
//            btnSubscribe.setVisibility(View.GONE);
//        }

        btnSubscribe.setOnClickListener(v -> startActivity(new Intent(getActivity(), SongListActivity.class)));
        btnSubscription.setOnClickListener(v -> startActivity(new Intent(getActivity(), SongListActivity.class)));

        searchField.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                if(s.length() != 0)
                    searchLocation();
            }
        });

        return view;
    }

    public void searchLocation() {
        String location = "shyambazar";//searchField.getText().toString();
        List<Address> addressList = null;

        if (location != null || !location.equals("")) {
            Geocoder geocoder = new Geocoder(getActivity());
            try {
                addressList = geocoder.getFromLocationName(location, 1);

            } catch (IOException e) {
                e.printStackTrace();
            }
            Address address = addressList.get(0);
            LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
            Toast.makeText(getActivity(),address.getLatitude()+" "+address.getLongitude(),Toast.LENGTH_LONG).show();
        }
    }

}
