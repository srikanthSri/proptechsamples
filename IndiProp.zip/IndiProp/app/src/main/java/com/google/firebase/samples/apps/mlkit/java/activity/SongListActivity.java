package com.google.firebase.samples.apps.mlkit.java.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.google.firebase.samples.apps.mlkit.R;
import com.google.firebase.samples.apps.mlkit.java.adapter.ItemAdapter;
import com.google.firebase.samples.apps.mlkit.java.bean.DataModel;

import java.util.ArrayList;

public class SongListActivity extends AppCompatActivity {

    private CardView item1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prop_list);
        item1 = findViewById(R.id.item1);
        item1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SongListActivity.this, PropActivity.class));
            }
        });
    }
}
