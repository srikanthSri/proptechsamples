package com.google.firebase.samples.apps.mlkit.java.fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.samples.apps.mlkit.R;
import com.google.firebase.samples.apps.mlkit.java.activity.SongListActivity;
import com.google.firebase.samples.apps.mlkit.java.view.ZoomableImageView;
import com.unity3d.player.UnityPlayerActivity;

import java.io.IOException;
import java.util.List;

import androidx.fragment.app.Fragment;

//import com.google.android.gms.vision.text.Line;

public class InteriorFragment extends Fragment {
    Button btnSubscribe, btnSubscription;
    View view;
    private RadioGroup radioGrpFlat;
    private RadioButton radioButton2bhk;
    private ZoomableImageView imgFlat;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_interior, container, false);
        btnSubscribe = view.findViewById(R.id.btnSubscribe);
        btnSubscription = view.findViewById(R.id.btnSubscription);
        imgFlat = view.findViewById(R.id.imgFlat);
        radioGrpFlat = view.findViewById(R.id.radioGroup);
        radioButton2bhk = view.findViewById(R.id.radioButton2bhk);
        radioButton2bhk.setChecked(true);
        Bitmap twobhk = BitmapFactory.decodeResource(getActivity().getResources(),
                R.drawable.twobhk);
        imgFlat.setImageBitmap(twobhk);

        radioGrpFlat.setOnCheckedChangeListener((group, checkedId) -> {
            switch(checkedId){
                case R.id.radioButton2bhk:
                    imgFlat.setImageBitmap(twobhk);
                    break;
                case R.id.radioButton3bhk:
                    Bitmap threebhk = BitmapFactory.decodeResource(getActivity().getResources(),
                            R.drawable.threebhk);
                    imgFlat.setImageBitmap(threebhk);
                    break;
            }
        });
        btnSubscription.setOnClickListener(v ->
        {
            //startActivity(new Intent(getActivity(), UnityPlayerActivity.class));
            Intent intent = getActivity().getPackageManager().getLaunchIntentForPackage("com.ARProp.ARProp");
            startActivity(intent);
        });

        return view;
    }
}
